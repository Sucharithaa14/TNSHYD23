/**
 * 
 */
/**
 * 
 */
module sample {
}